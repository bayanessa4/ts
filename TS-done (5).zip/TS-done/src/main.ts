var note1 : Note= new Meeting(new Date(2024, 3, 7, 22, 10), "Party with friends", "TLV City", "https://th.bing.com/th/id/OIP.80D9nj5Rj8T-YZ2z8y_TugHaE8?rs=1&pid=ImgDetMain", "Please do not be late", "welcome");
var note2 : Note= new Meeting(new Date(2024, 3, 8, 10, 30), "Eye test", "Afula", "https://www.royalspanishcenter.com/wp-content/uploads/2020/11/%D8%A7%D8%AE%D8%AA%D8%A8%D8%A7%D8%B1-%D9%82%D9%8A%D8%A7%D8%B3-%D8%A7%D9%84%D9%86%D8%B8%D8%B1.jpg", "Afula", "welcome");
var note3 : Note= new Meeting(new Date(2024, 3, 9, 15, 20), "GYM", "Ariel", "https://th.bing.com/th/id/OIP.4PGQXLmuAJwTa81MALENWQAAAA?rs=1&pid=ImgDetMain", "No pain No Gain", "GO!");
var note4 : Note = new Meeting(new Date(2024, 3, 10, 21, 25), "cinema", "Haifa", "https://th.bing.com/th/id/OIP.AedWjasj0N0euv6h6yDQ1gHaEK?rs=1&pid=ImgDetMain", 
        //this link is not working
        "So funny", "What did you want to watch!");
var note5 = new Meeting(new Date(2024, 3, 11, 10, 0), "Meeting with client", "Tel Aviv", "https://th.bing.com/th/id/R.0992c04fcec38a208bf381928cf885f0?rik=51%2bjRjeHBt4Jmw&pid=ImgRaw&r=0", "Conference room", "10:00 AM");
const notes: Note[] = [note1, note2, note3, note4,note5];
// until here the code is just to create the notes examples
const container = document.getElementById("notes-container") as HTMLDivElement;

var previousMode: string = "edit"; // this variable is used to store the previous mode
const modeSelector = {
  view: "edit",
  edit: "view",
}; // this object is used to change the mode

/**
 * this function adds a note to the container
 * @param note note to be added to the container
 */
function addNoteToContainer(note: Note) {
  container.innerHTML += `<div class="note"> <span class="close" id="${note.id}">X</span> </div>`;
  (container.lastElementChild as HTMLDivElement).innerHTML += note.intoHTML();
  (
    container.lastElementChild as HTMLDivElement
  ).innerHTML += `<button id="${note.id}" class="alert-button" onClick="() => alert()">Alert</button>`;
}
/**
 * this function makes the close buttons
 */
const closeButtonsInit = () => {
  document.querySelectorAll(".close").forEach((closeButton) => {
    /**
     * this function removes a note from the container
     */
    closeButton.addEventListener("click", () => {
      console.log(closeButton.id);
      removeNote(Number(closeButton.id));
    });
  });
};
/**
 * this function makes the alert buttons
 */
function alertButtonInit() {
  document.querySelectorAll(".alert-button").forEach((alertButton) => {
    /**
     * this function alerts a note
     */
    alertButton.addEventListener("click", () => {
      console.log(alertButton.id);
      notes.forEach((note) => {
        if (note.id === Number(alertButton.id)) {
          note.alert();
        }
      });
    });
  });
}

notes.forEach((note) => addNoteToContainer(note)); // this line adds the notes to the container
alertButtonInit(); // this line makes the alert buttons
closeButtonsInit(); // this line makes the close buttons
editButton(previousMode); // this line changes the mode based on the previous mode

/**
 * this function add an event listener to the edit button to change the mode
 */
document.getElementById("edit-button")?.addEventListener("click", () => {
  editButton(previousMode);
});
