class Meeting extends Note implements MeetingInterface {
  location: string;
  time: string;

  constructor(
    creationDate: Date,
    title: string,
    content: string,
    picUrl: string,
    location: string,
    time: string
  ) {
    super(creationDate, title, content, picUrl);
    this.location = location;
    this.time = time;
  }

  alert(): void {
    alert("Meeting alert!");
  }
  intoHTML(): string {
    return `
                    <div class="note-header">
                        <div class="note-title">${this.title}</div>
                        <div class="note-date">${this.creationDate.getDay()}/${this.creationDate.getMonth()}/${this.creationDate.getFullYear()} ${this.creationDate.getHours()}:${this.creationDate.getMinutes()}</div>
                    </div>
                    <div class="note-content">
                        <div class="note-text">${this.content}</div>
                        <div class="note-image"><img src="${this.picUrl}" alt="image"></div>
                    </div>
                    <div class="meeting-details">
                        <div class="meeting-location">${this.location}</div>
                        <div class="meeting-time">${this.time}</div>
                    </div>
                `;
  }
}