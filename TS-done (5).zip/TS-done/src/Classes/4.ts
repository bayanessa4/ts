class ToDoList extends Note implements ToDoListInterface {
  dueDate: Date;
  imageUrl: any;
  text: any;

  constructor(
    creationDate: Date,
    title: string,
    text: string,
    imageUrl: string,
    dueDate: Date
  ) {
    super(creationDate, title, text, imageUrl);
    this.dueDate = dueDate;
  }

  alert(): void {
    alert("ToDoList alert!");
  }
  intoHTML(): string {
    return `
                        <div class="note-header">
                            <div class="note-title">${this.title}</div>
                            <div class="note-date">${this.creationDate.getDay()}/${this.creationDate.getMonth()}/${this.creationDate.getFullYear()} ${this.creationDate.getHours()}:${this.creationDate.getMinutes()}</div>
                        </div>
                        <div class="note-content">
                            <div class="note-text">${this.text}</div>
                            <div class="note-image"><img src="${
                              this.imageUrl
                            }" alt="image"></div>
                        </div>
                        <div class="todo-details">
                            <div class="todo-due-date">${this.dueDate}</div>
                        </div>
                    `;
  }
}
