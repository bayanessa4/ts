class Sport extends Note implements SportInterface {
  location: string;
  eventDate: Date;
  time: string;
  requiredEquipment: string;
  text: any;
  imageUrl: any;

  constructor(
    creationDate: Date,
    title: string,
    text: string,
    imageUrl: string,
    location: string,
    eventDate: Date,
    time: string,
    requiredEquipment: string
  ) {
    super(creationDate, title, text, imageUrl);
    this.location = location;
    this.eventDate = eventDate;
    this.time = time;
    this.requiredEquipment = requiredEquipment;
  }

  alert(): void {
    alert("Sport event alert!");
  }
  intoHTML(): string {
    return `
                    <div class="note-header">
                        <div class="note-title">${this.title}</div>
                        <div class="note-date">${this.creationDate.getDay()}/${this.creationDate.getMonth()}/${this.creationDate.getFullYear()} ${this.creationDate.getHours()}:${this.creationDate.getMinutes()}</div>
                    </div>
                    <div class="note-content">
                        <div class="note-text">${this.text}</div>
                        <div class="note-image"><img src="${
                          this.imageUrl
                        }" alt="image"></div>
                    </div>
                    <div class="sport-details">
                        <div class="sport-location">${this.location}</div>
                        <div class="sport-event-date">${this.eventDate}</div>
                        <div class="sport-time">${this.time}</div>
                        <div class="sport-required-equipment">${
                          this.requiredEquipment
                        }</div>
                    </div>
                `;
  }
}
