abstract class Note {
  static noteCounter: number = -1;
  id: number;
  creationDate: Date;
  title: string;
  content: string;
  picUrl: string;

  constructor(
    creationDate: Date,
    title: string,
    content: string,
    picUrl: string
  ) {
    this.id = ++Note.noteCounter;
    this.creationDate = creationDate;
    this.title = title;
    this.content = content;
    this.picUrl = picUrl;
  }

  abstract alert(): void;
  abstract intoHTML(): string;
}