/**
 * change the display of the close and alert buttons
 * @param mode previous mode
 */
function editButton(mode: string): void {
  const closeButtons = document.querySelectorAll(
    ".close"
  ) as NodeListOf<HTMLSpanElement>;
  const alertButtons = document.querySelectorAll(
    ".alert-button"
  ) as NodeListOf<HTMLButtonElement>;
  switch ((previousMode = modeSelector[mode as keyof typeof modeSelector])) {
    case "view":
      closeButtons.forEach((closeButton) => {
        closeButton.style.display = "none";
      });

      alertButtons.forEach((alertButton) => {
        alertButton.style.display = "block";
      });
      break;

    case "edit":
      closeButtons.forEach((closeButton) => {
        closeButton.style.display = "block";
      });

      alertButtons.forEach((alertButton) => {
        alertButton.style.display = "none";
      });
      break;
  }
}
