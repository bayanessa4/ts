/**
 * this function adds a note to the container and the notes array
 * @param note note to be added to the container
 */
function addNote(note: Meeting | ToDoList | Sport) {
  notes.push(note);
  addNoteToContainer(note);
  closeButtonsInit();
  alertButtonInit();
}
