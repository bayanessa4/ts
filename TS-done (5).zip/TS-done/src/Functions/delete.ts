/**
 * this function removes a note from the notes array and the container
 * @param id id of the note to be removed
 */
function removeNote(id: number): void {
  notes.forEach((note, index) => {
    if (note.id === id) {
      notes.splice(index, 1);
    }
  });
  container.innerHTML = "";
  notes.forEach((note) => addNoteToContainer(note));
  closeButtonsInit();
  alertButtonInit();
}
