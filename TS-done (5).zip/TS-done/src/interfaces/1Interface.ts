interface MeetingInterface {
    location: string;
    time: string;
    alert(): void;
}