interface ToDoListInterface {
    dueDate: Date;
    alert(): void;
}