interface SportInterface {
    location: string;
    eventDate: Date;
    time: string;
    requiredEquipment: string;
    alert(): void;
}